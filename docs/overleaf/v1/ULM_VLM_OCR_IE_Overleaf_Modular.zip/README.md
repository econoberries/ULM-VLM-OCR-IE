# Modular Overleaf project — ULM VLM/OCR/IE paper

**Upload `ULM_VLM_OCR_IE_Overleaf_Modular.zip` to a new Overleaf project**, or upload its contents (not the parent folder) into your existing project. Set `main.tex` as the main document; use the **pdfLaTeX** compiler. The project was tested using `latexmk -pdf` (with no BibTeX requirement).

## Project map

- `main.tex` — preamble, title, and `\input` statements; edit rarely.
- `sections/00_abstract.tex` through `sections/10_references.tex` — paper text, split by responsibility.
- `tables/*.tex` — each data table lives in its own file and is included by the relevant section.
- `figures/results/*.pdf` — results charts generated from the measurements shared in this conversation.
- `figures/examples/*` — the **three actual document images supplied by the user**, not generated substitutes. The receipt JPEG has been rotated according to its EXIF orientation flag and re-encoded as JPEG for consistent LaTeX display; its visible content is unchanged.
- `figures/example_gallery.tex` — LaTeX layout for those example images.
- `sections/10_references.tex` — self-contained bibliography, editable without BibTeX.

## Edit one part at a time

To edit Qwen methods: `sections/03_data_methods.tex`.
To edit Qwen quantitative results: `sections/04_qwen_results.tex`.
To edit token sensitivity: `sections/05_sensitivity.tex`.
To edit inspected error examples: `sections/06_error_analysis.tex`.
To edit a single table: its corresponding file under `tables/`.

In your existing `main.tex`, remove the old `\section{...}` bodies before adding `\input`, or they will appear twice. Simpler: replace your current `main.tex` with the new one and upload all folders.

## Results status / boundaries

The Qwen3.5-9B **full English KIE experiment is completed** (400 documents): official mean field-match score 0.8699206208415767; reference-format-corrected diagnostic mean 0.8724206208415767; mean latency 4.91808075 seconds; median 4.27585 seconds; p95 11.005815 seconds; maximum peak PyTorch CUDA allocated memory 22.694459 GiB; model load 27.555 seconds; zero recorded runner inference failures.

These measurements are transcribed from the user-provided Helix experiment outputs, not recomputed from the raw per-example JSON (which was not provided to this drafting workspace). Rounded per-dataset results are displayed at the same precision as in the user-provided logs. The plot source arrays are documented in `figures/plot_data.csv`.

**The 1,024-token run was a post-hoc sensitivity study of four selected truncated FUNSD documents, not a new full-400 estimate.** The official baseline is unchanged. Cross-model sections remain unfilled because those experiments were not provided.

## Before publication

- Check citation style, author affiliations, and required length with the course.
- Verify the manuscript's rounded figures against the archived Helix result JSON files.
- Cite the benchmark and check its image-redistribution terms before publicly releasing the three example images.
- Record the actual software package versions and GPU configuration in a reproducibility appendix when available; `run_metadata.json` has some of them.
- Fill the other-model results and conclusion after team measurements are verified.
- Consider whether reference-key normalization and annotation audits should be specified as an additional standardized diagnostic protocol across all compared models.
