Qwen3.5-9B Helix Experiment Evidence - Version 1
Date: October 18, 2026
Project: ULM-VLM-OCR-IE

Main benchmark: OCRBench v2 English KIE, 400 documents
GPU: NVIDIA A100-SXM4-40GB
Official mean F1: 0.8699206208415767
Reference-corrected mean F1: 0.8724206208415767
Mean inference latency: 4.91808075 seconds

Includes generated predictions, recorded metrics,
experiment logs, metadata, and Qwen scripts.
Original dataset images, questions, reference answers,
model weights, and Python environments are excluded.
